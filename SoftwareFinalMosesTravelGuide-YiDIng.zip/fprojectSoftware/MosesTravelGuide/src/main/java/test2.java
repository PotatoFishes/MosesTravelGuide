
public class test2 {

	public static void main(String[] args) {
		User e=UserDAO.checkPassword("Wick", "dog");
		System.out.println(e);

	}

}
