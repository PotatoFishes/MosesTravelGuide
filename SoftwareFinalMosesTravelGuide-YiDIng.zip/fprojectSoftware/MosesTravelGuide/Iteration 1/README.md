PUT ALL RELATED MATERIAL HERE, CREATE FOLDERS AS NESSECARY
* [ Itr1 ppt](https://baylor0-my.sharepoint.com/:p:/g/personal/benjamin_kilpatrick1_baylor_edu/EWG4ZXg90yZAs37zNQt8v-cBaU_cG1sf-LXC2NJhMS6oZQ?e=3n6O92)
