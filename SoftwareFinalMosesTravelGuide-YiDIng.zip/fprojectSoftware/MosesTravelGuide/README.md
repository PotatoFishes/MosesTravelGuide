**[Moses Travel Guide Website](https://potatofishes.github.io/MosesTravelGuide/)**
* No need to mess with [website](https://potatofishes.github.io/MosesTravelGuide/) branch
* All documentation goes here, I will handle linking them to the website
* Create directories as needed
* [Iteration1 Document](https://baylor0-my.sharepoint.com/:w:/g/personal/benjamin_kilpatrick1_baylor_edu/EUcGaozR_glHtUu_5AXeCOQBihw7k1ezsnR1DwTqWSUedg?e=VE9ePJ)
* [Glossary](https://baylor0-my.sharepoint.com/:w:/g/personal/benjamin_kilpatrick1_baylor_edu/EflGR9307H1BjfLk7DVUCyQBFHDm1cB_QjMPRDU01izPcA?e=9lfUBT)
